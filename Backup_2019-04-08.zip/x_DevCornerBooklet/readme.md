Html, Css and Php based Responsive Blogging website - exercise
---

![x_DevCornerBooklet](https://github.com/r4nd3l/x_DevCornerBooklet/raw/master/public/img/sample.gif)

- Overwrite these files paths: (accoring to your system)
  - app/config/config.php
      define('URLROOT', 'http://localhost/Git/x_DevCornerBooklet');
  - public/.htaccess
      "RewriteBase /Git/x_DevCornerBooklet/public"
- Create the database in PhpMyAdmin and /db_init.php (in the URL) will do the rest
