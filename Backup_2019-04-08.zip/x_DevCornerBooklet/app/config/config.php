<?php
  // DB Params
  define('DB_HOST', 'localhost');
  define('DB_USER', 'root');
  define('DB_PASS', '');
  define('DB_NAME', 'booklet');

  // App root
  define('APPROOT', dirname(dirname(__FILE__)));

  // URL Root
  define('URLROOT', 'http://localhost/Git/x_DevCornerBooklet');

  // Site Name
  // define('SITENAME', 'mate_mvc');
  define('SITENAME', 'DevCornerBooklet');

  // App version
  define('APPVERSION', '1.0.0');
